import express from "express";
import pino from "pino";
import makeWASocket, {
  useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion,
  jidNormalizedUser, downloadContentFromMessage, Browsers
} from "@whiskeysockets/baileys";
import fs from "node:fs";
import path from "node:path";
import https from "node:https";
import http from "node:http";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, "data");
const SESSION_DIR = process.env.SESSION_DIR || path.join(__dirname, "sessions");
const STATE_FILE = path.join(DATA_DIR, "bot-state.json");
const STICKER_DIR = path.join(DATA_DIR, "stickers");
const IMAGE_DIR = path.join(DATA_DIR, "images");
const MAX_BOTS = 4;
const log = pino({ level: "silent" });
const bots = new Map();
const ownerNumbers = new Set();
const subAdmins = new Set();
const antilinkGroups = new Set();
const autoReplies = new Map();
const groupNameLocks = new Map();
const savedStickers = new Map();
const savedImages = new Map();
const cooldowns = new Map();
const logs = [];

for (const dir of [DATA_DIR, SESSION_DIR, STICKER_DIR, IMAGE_DIR]) {
  fs.mkdirSync(dir, { recursive: true });
}
if (!ADMIN_PASSWORD) {
  console.error("Missing ADMIN_PASSWORD. Set it in Render Environment.");
  process.exit(1);
}

app.use(express.json({ limit: "12kb" }));
app.use(express.static(path.join(__dirname, "public")));

function addLog(message) {
  const entry = { at: new Date().toISOString(), message: String(message).slice(0, 240) };
  logs.unshift(entry);
  if (logs.length > 60) logs.pop();
  console.log(entry.message);
}
function auth(req, res, next) {
  if (req.get("x-admin-password") !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "Dashboard password incorrect." });
  }
  next();
}
const digits = value => String(value || "").replace(/\D/g, "");
const jidNumber = jid => digits(String(jid || "").split("@")[0].split(":")[0]);
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const validBotId = id => /^[1-4]$/.test(String(id));
function getBot(id) {
  if (!validBotId(id)) return null;
  if (!bots.has(String(id))) {
    bots.set(String(id), {
      id: String(id), sock: null, status: "offline", phone: "",
      pairingCode: "", error: "", connecting: false
    });
  }
  return bots.get(String(id));
}
function persist() {
  const data = {
    ownerNumbers: [...ownerNumbers],
    subAdmins: [...subAdmins],
    antilinkGroups: [...antilinkGroups],
    autoReplies: Object.fromEntries(autoReplies),
    groupNameLocks: Object.fromEntries(groupNameLocks),
    savedStickers: Object.fromEntries([...savedStickers].map(([k,v]) => [k,[...v]])),
    savedImages: Object.fromEntries([...savedImages].map(([k,v]) => [k,[...v]]))
  };
  fs.writeFileSync(STATE_FILE, JSON.stringify(data, null, 2));
}
function loadState() {
  try {
    if (!fs.existsSync(STATE_FILE)) return;
    const d = JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
    (d.ownerNumbers || []).forEach(x => ownerNumbers.add(x));
    (d.subAdmins || []).forEach(x => subAdmins.add(x));
    (d.antilinkGroups || []).forEach(x => antilinkGroups.add(x));
    Object.entries(d.autoReplies || {}).forEach(([k,v]) => autoReplies.set(k,v));
    Object.entries(d.groupNameLocks || {}).forEach(([k,v]) => groupNameLocks.set(k,v));
    Object.entries(d.savedStickers || {}).forEach(([k,v]) => savedStickers.set(k,new Set(v)));
    Object.entries(d.savedImages || {}).forEach(([k,v]) => savedImages.set(k,new Set(v)));
  } catch (e) { addLog("State file could not be loaded: " + e.message); }
}
loadState();

function isOwner(jid) {
  const n = jidNumber(jid);
  return ownerNumbers.has(n) || ownerNumbers.has(jid);
}
function isAuthorized(jid) {
  const n = jidNumber(jid);
  return isOwner(jid) || subAdmins.has(n) || subAdmins.has(jid);
}
function activeSockets(count = 1) {
  return [...bots.values()].filter(b => b.status === "connected" && b.sock)
    .sort((a,b) => Number(a.id)-Number(b.id)).slice(0,count).map(b => b.sock);
}
async function sendText(jid, text, quoted) {
  const sock = activeSockets(1)[0];
  if (!sock) return;
  await sock.sendMessage(jid, { text }, quoted ? { quoted } : {});
}
function unwrapMessage(message) {
  let m = message || {};
  for (const key of ["ephemeralMessage","viewOnceMessage","viewOnceMessageV2","documentWithCaptionMessage"]) {
    if (m[key]?.message) m = m[key].message;
  }
  return m;
}
function getBody(message) {
  const m = unwrapMessage(message);
  return m.conversation || m.extendedTextMessage?.text ||
    m.imageMessage?.caption || m.videoMessage?.caption || "";
}
function isGroupAdmin(metadata, jid) {
  const n = jidNumber(jid);
  return metadata?.participants?.some(p =>
    [p.id,p.phoneNumber,p.lid].filter(Boolean).some(x => jidNumber(x) === n) &&
    ["admin","superadmin"].includes(p.admin)
  );
}
async function downloadMessageMedia(mediaMessage, type, maxBytes) {
  const stream = await downloadContentFromMessage(mediaMessage, type);
  const chunks = [];
  let size = 0;
  for await (const chunk of stream) {
    size += chunk.length;
    if (size > maxBytes) throw new Error(`Media exceeds ${Math.round(maxBytes/1024/1024)} MB limit.`);
    chunks.push(chunk);
  }
  if (!size) throw new Error("Empty media file.");
  return Buffer.concat(chunks);
}
function safeName(value) {
  return String(value || "media").replace(/[^\w.-]+/g, "_").slice(0,80);
}
function mediaPath(type, jid, id) {
  const folder = type === "sticker" ? STICKER_DIR : IMAGE_DIR;
  const ext = type === "sticker" ? "webp" : "img";
  return path.join(folder, `${Buffer.from(jid).toString("hex")}_${id}.${ext}`);
}

async function fetchJson(url) {
  const response = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(15000) });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}
function downloadBuffer(url, redirects = 0) {
  return new Promise((resolve, reject) => {
    if (redirects > 5) return reject(new Error("Too many redirects."));
    const mod = url.startsWith("https:") ? https : http;
    const req = mod.get(url, { headers: { "User-Agent": "Mozilla/5.0" } }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume(); return resolve(downloadBuffer(new URL(res.headers.location,url).toString(), redirects+1));
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error(`Download HTTP ${res.statusCode}`)); }
      const chunks=[]; let size=0;
      res.on("data", chunk => { size += chunk.length; if (size > 25*1024*1024) req.destroy(new Error("Download too large.")); else chunks.push(chunk); });
      res.on("end", () => resolve(Buffer.concat(chunks)));
    });
    req.on("error", reject);
    req.setTimeout(20000, () => req.destroy(new Error("Download timeout.")));
  });
}
async function searchJioSaavn(query) {
  const data = await fetchJson(`https://jiosavan-api2.vercel.app/api/search/songs?query=${encodeURIComponent(query)}&limit=5`);
  const songs = data?.data?.results || [];
  for (const song of songs) {
    const urls = [...(song.downloadUrl || [])].sort((a,b) => parseInt(b.quality)-parseInt(a.quality));
    const best = urls.find(x => x.url?.startsWith("https://"));
    if (best) return {
      title: song.name || query,
      artist: song.artists?.primary?.map(a => a.name).join(", ") || "Unknown",
      album: song.album?.name || "",
      duration: song.duration || 0,
      image: song.image?.at(-1)?.url || song.imageUrl || null,
      audioUrl: best.url
    };
  }
  return null;
}
async function searchAudius(query) {
  const hosts = await fetchJson("https://api.audius.co");
  const host = hosts?.data?.[0];
  if (!host) return null;
  const data = await fetchJson(`${host}/v1/tracks/search?query=${encodeURIComponent(query)}&limit=1&app_name=RajXMafia`);
  const track = data?.data?.[0];
  return track ? {
    title: track.title, artist: track.user?.name || "Unknown",
    streamUrl: `${host}/v1/tracks/${track.id}/stream?app_name=RajXMafia`
  } : null;
}
function formatDuration(seconds) {
  const n = Number(seconds || 0);
  return n ? `${Math.floor(n/60)}:${String(n%60).padStart(2,"0")}` : "";
}

function menuText() {
  return `╔══〔 RAJ X MAFIA 〕══╗
/menu — commands
/status — bot status
/song <name> — search JioSaavn
/gana <name> — song search alias
/geet <name> — Audius search
/antilink on|off|info — group link moderation
/gcpronc <name>|off — restore protected group name
/ar <number> <message> — set DM auto-reply
/ar off <number>|all|list
/sticker save <id> — reply to a sticker
/sticker <id> — send saved sticker once
/image save <id> — reply to an image
/image <id> — send saved image once
/addsubadmin — owner only, mention user
/removesubadmin — owner only, mention user
/listsubadmin — list sub-admins
/remove — remove mentioned member (group admins only)
 /stopall — stop persistent moderation features
╚══════════════════════╝`;
}

async function handleCommand(sock, m, body, jid, sender, isGroup) {
  const parts = body.trim().split(/\s+/);
  const cmd = (parts[0] || "").toLowerCase();
  const arg = parts.slice(1);

  if (cmd === "/menu") return sendText(jid, menuText(), m);
  if (cmd === "/status") {
    const status = [...bots.values()].map(b => `Bot ${b.id}: ${b.status}`).join("\n");
    return sendText(jid, `🤖 *RAJ X Mafia Status*\n${status}\nGroups with antilink: ${antilinkGroups.size}\nAuto-replies: ${autoReplies.size}`, m);
  }

  if (cmd === "/song" || cmd === "/gana") {
    const query = arg.join(" ");
    if (!query) return sendText(jid, "Song name likho. Example: /song Tum Hi Ho", m);
    await sendText(jid, `🔎 Searching: *${query}*`, m);
    try {
      const song = await searchJioSaavn(query);
      if (!song) return sendText(jid, "Song nahi mila. Dusra naam try karo.", m);
      const audio = await downloadBuffer(song.audioUrl);
      const caption = `🎵 *${song.title}*\n🎤 ${song.artist}\n💿 ${song.album}\n${formatDuration(song.duration)}`;
      if (song.image) {
        try { await sock.sendMessage(jid, { image: await downloadBuffer(song.image), caption }, { quoted: m }); } catch {}
      }
      return sock.sendMessage(jid, { audio, mimetype: "audio/mp4", fileName: `${safeName(song.title)}.m4a`, ptt: false }, { quoted: m });
    } catch (e) { return sendText(jid, `Song error: ${e.message}`, m); }
  }

  if (cmd === "/geet") {
    const query = arg.join(" ");
    if (!query) return sendText(jid, "Song name likho. Example: /geet Tum Hi Ho", m);
    try {
      const track = await searchAudius(query);
      if (!track) return sendText(jid, "Audius par track nahi mila.", m);
      const audio = await downloadBuffer(track.streamUrl);
      return sock.sendMessage(jid, { audio, mimetype: "audio/mpeg", fileName: `${safeName(track.title)}.mp3` }, { quoted: m });
    } catch (e) { return sendText(jid, `Audius error: ${e.message}`, m); }
  }

  if (cmd === "/antilink") {
    if (!isGroup) return sendText(jid, "Ye command group mein use karo.", m);
    if (!isAuthorized(sender)) return;
    const action = (arg[0] || "").toLowerCase();
    if (action === "on") antilinkGroups.add(jid);
    else if (action === "off") antilinkGroups.delete(jid);
    else if (action === "info") return sendText(jid, `Antilink: ${antilinkGroups.has(jid) ? "ON" : "OFF"}`, m);
    else return sendText(jid, "Use /antilink on, /antilink off, or /antilink info", m);
    persist();
    return sendText(jid, `Antilink ${action.toUpperCase()} ho gaya.`, m);
  }

  if (cmd === "/gcpronc") {
    if (!isGroup || !isAuthorized(sender)) return;
    const value = arg.join(" ").trim();
    if (!value) return sendText(jid, "Use /gcpronc <group name> or /gcpronc off", m);
    if (value.toLowerCase() === "off") groupNameLocks.delete(jid);
    else groupNameLocks.set(jid, value.slice(0,100));
    persist();
    if (value.toLowerCase() !== "off") {
      try { await sock.groupUpdateSubject(jid, value.slice(0,100)); } catch (e) {
        return sendText(jid, `Lock saved, but bot could not change group name: ${e.message}`, m);
      }
    }
    return sendText(jid, value.toLowerCase() === "off" ? "Group-name protection off." : `Group-name protection on: ${value}`, m);
  }

  if (cmd === "/ar") {
    if (!isAuthorized(sender)) return;
    const sub = (arg[0] || "").toLowerCase();
    if (sub === "list") return sendText(jid, autoReplies.size
      ? [...autoReplies].map(([n,v]) => `${n}: ${v}`).join("\n") : "No auto replies set.", m);
    if (sub === "off" && (arg[1] || "").toLowerCase() === "all") {
      autoReplies.clear(); persist(); return sendText(jid, "All auto replies cleared.", m);
    }
    if (sub === "off" && arg[1]) {
      autoReplies.delete(digits(arg[1])); persist(); return sendText(jid, "Auto reply removed.", m);
    }
    const number = digits(arg[0]);
    const message = arg.slice(1).join(" ");
    if (number.length < 8 || number.length > 15 || !message) {
      return sendText(jid, "Use /ar +919876543210 I am busy\n/ar off +919876543210\n/ar off all\n/ar list", m);
    }
    autoReplies.set(number, message.slice(0,500)); persist();
    return sendText(jid, `Auto reply set for ${number}.`, m);
  }

  if (cmd === "/sticker" || cmd === "/image") {
    if (!isGroup) return sendText(jid, "Media save/send commands group mein use karo.", m);
    if (!isAuthorized(sender)) return;
    const type = cmd.slice(1);
    const action = (arg[0] || "").toLowerCase();
    const id = String(Number(arg[1] || arg[0]));
    const store = type === "sticker" ? savedStickers : savedImages;
    if (action === "save") {
      if (!/^[1-9]\d{0,2}$/.test(arg[1] || "")) return sendText(jid, `Use /${type} save <1-999> while replying to media.`, m);
      const quoted = unwrapMessage(m.message)?.extendedTextMessage?.contextInfo?.quotedMessage || {};
      const media = type === "sticker" ? quoted.stickerMessage : quoted.imageMessage;
      if (!media) return sendText(jid, `Reply to a ${type} with /${type} save ${arg[1]}.`, m);
      try {
        const buffer = await downloadMessageMedia(media, type, type === "sticker" ? 2*1024*1024 : 8*1024*1024);
        fs.writeFileSync(mediaPath(type,jid,arg[1]), buffer);
        if (!store.has(jid)) store.set(jid,new Set());
        store.get(jid).add(String(Number(arg[1])));
        persist();
        return sendText(jid, `${type} saved as ${arg[1]}.`, m);
      } catch (e) { return sendText(jid, `Save failed: ${e.message}`, m); }
    }
    if (!/^[1-9]\d{0,2}$/.test(arg[0] || "") || arg.length !== 1) {
      return sendText(jid, `Use /${type} save <id> (reply to media), then /${type} <id> to send once.`, m);
    }
    const file = mediaPath(type,jid,arg[0]);
    if (!store.get(jid)?.has(String(Number(arg[0]))) || !fs.existsSync(file)) return sendText(jid, `${type} ${arg[0]} not found in this group.`, m);
    const key = `${jid}:${jidNumber(sender)}:${type}`;
    const last = cooldowns.get(key) || 0;
    if (Date.now()-last < 5000) return sendText(jid, "Please wait 5 seconds before sending another saved media.", m);
    cooldowns.set(key,Date.now());
    const buffer = fs.readFileSync(file);
    return type === "sticker"
      ? sock.sendMessage(jid,{ sticker: buffer },{ quoted:m })
      : sock.sendMessage(jid,{ image: buffer, mimetype:"image/jpeg" },{ quoted:m });
  }

  if (cmd === "/addsubadmin" || cmd === "/removesubadmin") {
    if (!isOwner(sender)) return sendText(jid, "Owner only command.", m);
    const mentions = unwrapMessage(m.message)?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentions.length) return sendText(jid, "Kisi user ko mention karo.", m);
    for (const item of mentions) {
      const n = jidNumber(item);
      if (cmd === "/addsubadmin") subAdmins.add(n); else subAdmins.delete(n);
    }
    persist();
    return sendText(jid, `${cmd === "/addsubadmin" ? "Added" : "Removed"}: ${mentions.map(jidNumber).join(", ")}`, m);
  }
  if (cmd === "/listsubadmin") return sendText(jid, subAdmins.size ? [...subAdmins].join("\n") : "No sub-admins.", m);

  if (cmd === "/remove") {
    if (!isGroup) return sendText(jid, "Group mein use karo.", m);
    const meta = await sock.groupMetadata(jid);
    if (!isGroupAdmin(meta,sender) || !isGroupAdmin(meta,sock.user?.id)) {
      return sendText(jid, "Only group admins can use this, and the bot must be an admin.", m);
    }
    const mentions = unwrapMessage(m.message)?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    if (!mentions.length) return sendText(jid, "Use /remove @member", m);
    await sock.groupParticipantsUpdate(jid, mentions, "remove");
    return sendText(jid, "Requested group member removal.", m);
  }

  if (cmd === "/stopall") {
    // There are no repeated-send or group-toggle loops in this safe build.
    return sendText(jid, "No repeating tasks are running in this build.", m);
  }
}

async function startBot(id, phone = "") {
  const bot = getBot(id);
  if (!bot) throw new Error("Choose bot 1 to 4.");
  if (bot.connecting) throw new Error("This bot is already starting.");
  if (bot.status === "connected") throw new Error("This bot is already connected.");
  bot.connecting = true;
  bot.status = "connecting";
  bot.error = "";
  bot.pairingCode = "";
  const folder = path.join(SESSION_DIR, `bot${id}`);
  fs.mkdirSync(folder,{recursive:true});
  const { state, saveCreds } = await useMultiFileAuthState(folder);
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({
    version, logger: log, auth: state, printQRInTerminal: false,
    browser: Browsers.macOS("Chrome"), syncFullHistory: false,
    markOnlineOnConnect: false, generateHighQualityLinkPreview: false
  });
  bot.sock = sock;
  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "open") {
      bot.status = "connected"; bot.connecting = false; bot.pairingCode = "";
      bot.phone = jidNumber(sock.user?.id) || bot.phone;
      if (bot.phone) ownerNumbers.add(bot.phone);
      persist();
      addLog(`Bot ${id} connected (${bot.phone || "WhatsApp account"}).`);
    }
    if (connection === "close") {
      bot.status = "offline"; bot.connecting = false; bot.sock = null; bot.pairingCode = "";
      const code = lastDisconnect?.error?.output?.statusCode;
      bot.error = code === DisconnectReason.loggedOut ? "Logged out. Clear session to pair again." : `Connection closed (${code || "unknown"}).`;
      addLog(`Bot ${id} disconnected: ${bot.error}`);
      if (code !== DisconnectReason.loggedOut) {
        setTimeout(() => startBot(id).catch(e => addLog(`Bot ${id} reconnect error: ${e.message}`)), 5000);
      }
    }
  });

  sock.ev.on("groups.update", async updates => {
    if (String(id) !== "1") return;
    for (const update of updates || []) {
      const group = update.id || update.jid;
      const protectedName = groupNameLocks.get(group);
      if (!protectedName || typeof update.subject !== "string" || update.subject === protectedName) continue;
      try {
        const meta = await sock.groupMetadata(group);
        if (isGroupAdmin(meta,sock.user?.id)) await sock.groupUpdateSubject(group,protectedName);
      } catch (e) { addLog(`Group-name protection failed: ${e.message}`); }
    }
  });

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (!["notify","append"].includes(type)) return;
    for (const m of messages || []) {
      try {
        if (!m.message || !m.key?.remoteJid) continue;
        const jid = m.key.remoteJid;
        const isGroup = jid.endsWith("@g.us");
        const sender = isGroup ? (m.key.participant || jid) : (m.key.fromMe ? sock.user?.id : jid);
        const body = getBody(m.message).trim();
        if (!m.key.fromMe && !isGroup) {
          const num = jidNumber(sender);
          const reply = autoReplies.get(num);
          if (reply && String(id) === "1") await sock.sendMessage(jid,{text:reply},{quoted:m});
        }
        if (!m.key.fromMe && isGroup && antilinkGroups.has(jid) &&
            /https?:\/\/\S+|chat\.whatsapp\.com\/\S+|wa\.me\/\S+/i.test(body)) {
          try {
            const meta = await sock.groupMetadata(jid);
            if (isGroupAdmin(meta,sock.user?.id)) {
              await sock.sendMessage(jid,{delete:{remoteJid:jid,fromMe:false,id:m.key.id,participant:m.key.participant}});
            }
          } catch (e) { addLog(`Antilink moderation failed: ${e.message}`); }
        }
        if (String(id) !== "1" || !body.startsWith("/") || !isAuthorized(sender)) continue;
        await handleCommand(sock,m,body,jid,sender,isGroup);
      } catch (e) { addLog(`Message handler error: ${e.message}`); }
    }
  });

  if (!state.creds.registered && phone) {
    await sleep(1800);
    const code = await sock.requestPairingCode(phone);
    bot.pairingCode = code.match(/.{1,4}/g)?.join("-") || code;
    bot.phone = phone;
    bot.status = "waiting_for_pairing";
    addLog(`Pairing code generated for Bot ${id}.`);
  } else if (!state.creds.registered) {
    bot.status = "waiting_for_number";
  }
  return bot;
}

// Reconnect existing registered sessions after service restart.
async function bootExistingSessions() {
  for (let i=1;i<=MAX_BOTS;i++) {
    const creds = path.join(SESSION_DIR,`bot${i}`,"creds.json");
    if (fs.existsSync(creds)) {
      try { await startBot(String(i)); await sleep(900); }
      catch (e) { addLog(`Bot ${i} startup failed: ${e.message}`); }
    }
  }
}
bootExistingSessions().catch(e => addLog(`Startup error: ${e.message}`));

app.get("/api/status", auth, (req,res) => {
  res.json({
    bots: [1,2,3,4].map(i => {
      const b=getBot(String(i));
      return { id:b.id,status:b.status,phone:b.phone,pairingCode:b.pairingCode,error:b.error };
    }),
    logs
  });
});
app.post("/api/pair", auth, async (req,res) => {
  try {
    const { botId, phone } = req.body || {};
    if (!validBotId(botId)) return res.status(400).json({error:"Choose Bot 1, 2, 3 or 4."});
    const number = digits(phone);
    if (!/^[1-9]\d{7,14}$/.test(number)) return res.status(400).json({error:"Enter country code and phone number, digits only."});
    const bot = await startBot(String(botId),number);
    res.json({ok:true,status:bot.status,pairingCode:bot.pairingCode});
  } catch (e) { res.status(400).json({error:e.message || "Pairing failed."}); }
});
app.post("/api/reconnect", auth, async (req,res) => {
  try {
    const {botId}=req.body||{};
    if (!validBotId(botId)) return res.status(400).json({error:"Invalid bot number."});
    const b=getBot(String(botId));
    if (b.status==="connected") return res.json({ok:true,status:b.status});
    await startBot(String(botId));
    res.json({ok:true,status:b.status});
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.get("/health", (req,res)=>res.status(200).send("ok"));
app.listen(PORT,"0.0.0.0",()=>addLog(`Web dashboard listening on port ${PORT}.`));
